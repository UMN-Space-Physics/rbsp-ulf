Basic:
  Standard THEMIS mission cribs.
Advanced:
  Lots of speciality operations.
Deprecated:
  Cribs superceded by newer cribs or demonstrating operations that are no longer supported.
Tplot Plotting:
  Located in ssl_general/examples
