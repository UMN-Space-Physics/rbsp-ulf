These calibration files are here for reference only.  They are not used directly by the calibration procedures.  
The versions used by the IDL code live on the themis data directory servers e.g. themis.ssl.berkeley.edu/data/themis/tha/l1/0000/tha_psif_calib_params.txt
After you call thm_load_sst2, the most recent version of the calibration file is copied to your local data directory.  By default this will be:
Windows:
C:\data\themis\tha\l1\0000\
Linux/Mac/Unix:
~/data/themis/tha/l1/0000/



 