#ifndef ESTEPS_PRT_H
#define ESTEPS_PRT_H

extern FILE *elswp_fp;
extern FILE *ehswp_fp;
extern FILE *plswp_fp;
extern FILE *phswp_fp;

#endif
