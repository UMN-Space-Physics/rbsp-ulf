#include "date.h"

char *compile_date= __TIME__ "  " __DATE__;
