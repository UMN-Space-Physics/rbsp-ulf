#ifndef MAP_ELC_H
#define MAP_ELC_H

#include "defs.h"
#define E30 0x8000
#define E0 0x4000

extern uint ptmap_elc[16*32];

#endif MAP_ELC_H
