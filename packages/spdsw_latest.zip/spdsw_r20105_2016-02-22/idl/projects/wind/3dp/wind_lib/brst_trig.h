#include "pmom_dcm.h"

burst_trigger_pl(uchar e_start,comp_pesa_mom *cmp);
