#ifndef MAP_0_H
#define MAP_0_H

#include "defs.h"
#define E30 0x8000
#define E0 0x4000

extern uint ptmap_0[24*32];

#endif MAP_0_H
