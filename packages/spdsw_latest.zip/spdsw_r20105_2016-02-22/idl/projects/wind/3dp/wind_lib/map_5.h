#ifndef MAP_5_H
#define MAP_5_H

#include "defs.h"
#define E30 0x8000
#define E0 0x4000

extern uint ptmap_5[24*32];

#endif MAP_5_H
