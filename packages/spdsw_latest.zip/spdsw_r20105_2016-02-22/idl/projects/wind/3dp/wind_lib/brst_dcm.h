#ifndef BRST_DCM_H
#define BRST_DCM_H

#include "wind_pk.h"


int decompress_burst_packet(packet *uncomp,packet *comp);


#endif
