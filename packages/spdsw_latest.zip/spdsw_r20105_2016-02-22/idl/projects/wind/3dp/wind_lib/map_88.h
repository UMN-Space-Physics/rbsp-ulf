#ifndef MAP_88_H
#define MAP_88_H

#include "defs.h"
#define E30 0x8000
#define E0 0x4000

extern uint ptmap_88[16*32];

#endif MAP_88_H
