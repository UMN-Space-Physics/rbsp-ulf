#ifndef HKP_PRT_H
#define HKP_PRT_H



int print_hkp_packet(packet *pk);
extern FILE *hkp_main_fp;
extern FILE *hkp_mvolts_fp;
extern FILE *hkp_pesa_fp;
extern FILE *hkp_eesa_fp;
extern FILE *hkp_temp_fp;
extern FILE *hkp_log_fp;
extern FILE *hkp_sum_fp;
extern FILE *hkp_bin_fp;




#endif
