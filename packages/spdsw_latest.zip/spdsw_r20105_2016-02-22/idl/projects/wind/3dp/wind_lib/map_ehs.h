#ifndef MAP_EHS_H
#define MAP_EHS_H

#include "defs.h"
#define E30 0x8000
#define E0 0x4000

extern uint ptmap_ehs[24*32];

#endif MAP_EHS_H
