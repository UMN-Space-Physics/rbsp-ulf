#ifndef MAP_22D_H
#define MAP_22D_H

#include "defs.h"
#define E30 0x8000
#define E0 0x4000

extern uint ptmap_22d[24*32];

#endif MAP_22D_H
