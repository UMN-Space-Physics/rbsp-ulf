#ifndef MAP_11B_H
#define MAP_11B_H

#include "defs.h"
#define E30 0x8000
#define E0 0x4000

extern uint ptmap_11b[24*32];

#endif MAP_11B_H
