
#if !defined(__P3D_TIME_H__)
#define __P3D_TIME_H__

int get_time_points(PACKET_ID pkid, int max_array, double * time_array);

#endif /* !defined(__P3D_TIME_H__) */
