#ifndef MAP_8_H
#define MAP_8_H

#include "defs.h"
#define E30 0x8000
#define E0 0x4000

extern uint ptmap_8[24*32];

#endif MAP_8_H
