#ifndef DATE_H
#define DATE_H

extern char* compile_date;


#endif
