This directory (and subdirectories) only contain code that 
is needed to read and decomutate WIND 3DP Level-Zero files (raw data).